/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  UOIP GOD MODE DASHBOARD — South Zone Command Center                       ║
 * ║  Petpooja Merchant Training Operations | Abdus Salam, Zonal Manager        ║
 * ║  Replit-ready React JSX | Claude AI Copilot | Predictive Analytics         ║
 * ║  /godmode v3.0 — 2026                                                       ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * DEPLOYMENT GUIDE:
 * 1. Paste this file as src/App.jsx in a Replit React project
 * 2. Run: npm install recharts lucide-react
 * 3. No API keys needed — Claude AI tab is powered by Claude.ai Artifacts API
 * 4. All data is simulated with realistic South Zone trainer profiles
 */

import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import {
  LayoutDashboard, MapPin, BarChart3, Users, Zap, TrendingUp,
  TrendingDown, AlertTriangle, CheckCircle, XCircle, Clock, RefreshCw,
  Phone, MessageSquare, Download, Filter, ChevronUp, ChevronDown,
  Star, Award, Target, Activity, ShieldAlert, Brain, Sparkles,
  Send, Copy, Sun, Moon, Bell, Settings, LogOut, Database,
  FileText, PieChart, Grid, Search, Flame, ArrowUpRight,
  ArrowDownRight, Minus, Info, Eye, ChevronRight, Package
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, PieChart as RPieChart, Pie, Cell,
  RadialBarChart, RadialBar, ScatterChart, Scatter, ZAxis,
  AreaChart, Area, ComposedChart
} from "recharts";

// ═══════════════════════════════════════════════════════
// DESIGN TOKENS — Petpooja God Mode Palette
// ═══════════════════════════════════════════════════════
const C = {
  brand: "#FF6B00",
  brandDim: "#FF6B0020",
  brandBorder: "#FF6B0040",
  bg: "#080A0F",
  surface: "#0F1117",
  card: "#141820",
  cardBorder: "#1E2433",
  cardHover: "#1A2030",
  success: "#00C896",
  successDim: "#00C89615",
  warning: "#FFB020",
  warningDim: "#FFB02015",
  danger: "#FF3B5C",
  dangerDim: "#FF3B5C15",
  info: "#3B82F6",
  infoDim: "#3B82F615",
  purple: "#8B5CF6",
  purpleDim: "#8B5CF615",
  text: "#F0F4FF",
  textMuted: "#6B7280",
  textSub: "#9CA3AF",
};

// ═══════════════════════════════════════════════════════
// SOUTH ZONE DATA ENGINE — 70+ Trainer Simulation
// ═══════════════════════════════════════════════════════
const TEAM_LEADERS = [
  { id: "anil", name: "Anil Kumar P", state: "Tamil Nadu", color: "#FF6B00" },
  { id: "shyju", name: "Shyju V", state: "Kerala", color: "#00C896" },
  { id: "mushtaq", name: "Mushtaq Ahmed", state: "Andhra Pradesh", color: "#3B82F6" },
  { id: "priya", name: "Priya R", state: "Karnataka", color: "#8B5CF6" },
  { id: "kiran", name: "Kiran D", state: "Telangana", color: "#FFB020" },
];

const STATES = ["Tamil Nadu", "Karnataka", "Andhra Pradesh", "Kerala", "Telangana"];
const CITIES = {
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Trichy", "Salem", "Vellore", "Tiruppur", "Pondicherry"],
  "Karnataka": ["Bangalore", "Mysore", "Hubli", "Mangalore", "Belgaum", "Davanagere", "Hosur"],
  "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Tirupathi", "Rajamahendravaram"],
  "Kerala": ["Trivandrum", "Kochi", "Kozhikode", "Thrissur", "Kannur", "Kollam", "Alappuzha"],
  "Telangana": ["Hyderabad", "Warangal", "Karimnagar", "Nizamabad", "Sangareddy"],
};

const MODULES = ["POS", "KOT", "Reports", "Menu", "Settings", "Full Training", "Retraining"];
const TL_MAP = {
  "Tamil Nadu": "anil", "Kerala": "shyju", "Andhra Pradesh": "mushtaq",
  "Karnataka": "priya", "Telangana": "kiran"
};

function seededRandom(seed) {
  let s = seed;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

function generateTrainers() {
  const rand = seededRandom(42);
  const names = [
    "Ravi Kumar", "Pradeep S", "Suresh Kumar", "Venkatesh P", "Ramesh T",
    "Anand M", "Karthik R", "Srinivasan G", "Balaji N", "Murugan K",
    "Senthil A", "Palani S", "Dinesh V", "Vignesh C", "Arun P",
    "Mahesh B", "Naresh D", "Praveen K", "Rajesh M", "Santosh R",
    "Deepak S", "Ganesh L", "Harish T", "Jagan P", "Kiran M",
    "Lokesh B", "Manju N", "Naveen K", "Omkar R", "Prasad V",
    "Rahul J", "Sampath K", "Thamizh A", "Uday B", "Vijay R",
    "Abhishek N", "Bharat D", "Chandan S", "Divakar M", "Eshwar P",
    "Gokul R", "Hitesh S", "Imran K", "Jagadish B", "Krishnan V",
    "Lakshmanan T", "Manohar K", "Nandan R", "Omkar S", "Prabhu N",
    "Rajkumar A", "Saravanan M", "Thiyagarajan K", "Uma R", "Vasanth P",
    "Wahid K", "Xavier J", "Yashwant R", "Zaheer K", "Aarav S",
    "Balu T", "Chandran R", "Devraj N", "Eswaran K", "Fazil M",
    "Girish P", "Hanuman R", "Indra S", "Jeeva K", "Kamalan T",
  ];

  const trainers = [];
  STATES.forEach((state, si) => {
    const cities = CITIES[state];
    const tlId = TL_MAP[state];
    const tl = TEAM_LEADERS.find(t => t.id === tlId);
    const count = si === 0 ? 16 : si === 1 ? 15 : si === 2 ? 14 : si === 3 ? 13 : 12;

    for (let i = 0; i < count; i++) {
      const nameIdx = (si * 15 + i) % names.length;
      const sessions = Math.floor(rand() * 7);
      const checkedIn = rand() > 0.22;
      const badge = sessions >= 5 ? "gold" : sessions >= 3 ? "silver" : "bronze";
      const city = cities[i % cities.length];
      const crmUpdated = checkedIn && rand() > 0.3;
      const fatalIssues = Math.floor(rand() * 3);
      const weekData = Array.from({length: 7}, () => Math.floor(rand() * 7));

      trainers.push({
        id: `tr-${si}-${i}`,
        name: names[nameIdx],
        email: `${names[nameIdx].toLowerCase().replace(" ", ".")}_${si}${i}@petpooja.com`,
        phone: `9${Math.floor(rand() * 900000000 + 100000000)}`,
        state, city, team_leader: tl.name, tl_id: tlId,
        employee_code: `PJ-${state.substring(0,2).toUpperCase()}-${100 + i + si*20}`,
        is_checked_in: checkedIn,
        check_in_time: checkedIn ? new Date(Date.now() - rand() * 4 * 3600000).toISOString() : null,
        check_out_time: !checkedIn && rand() > 0.5 ? new Date(Date.now() - rand() * 2 * 3600000).toISOString() : null,
        today_sessions: sessions,
        weekly_sessions: weekData,
        badge_level: badge,
        star_rating: 3 + rand() * 2,
        last_crm_update: crmUpdated
          ? new Date(Date.now() - rand() * 3 * 3600000).toISOString()
          : new Date(Date.now() - rand() * 24 * 3600000).toISOString(),
        leadsquared_sync: {
          activities_today: Math.floor(rand() * 6),
          leads_created: Math.floor(rand() * 4),
          leads_updated: Math.floor(rand() * 8),
          last_sync: new Date(Date.now() - rand() * 3600000).toISOString(),
        },
        zoho_sync: {
          open_tickets: Math.floor(rand() * 5),
          fatal_issues: fatalIssues,
          avg_resolution_time: 1 + rand() * 5,
          last_sync: new Date(Date.now() - rand() * 1800000).toISOString(),
        },
        next_day_availability: rand() > 0.3 ? {
          status: ["available", "available", "available", "wfh", "half_day", "leave"][Math.floor(rand() * 6)],
          available_from: "09:00", available_until: "18:00",
          notes: "", submitted_at: new Date().toISOString(), submitted_for_date: new Date(Date.now() + 86400000).toISOString().split("T")[0]
        } : null,
        retraining_rate: Math.floor(rand() * 25),
        physical_sessions: Math.floor(sessions * (0.5 + rand() * 0.5)),
        session_history: Array.from({length: 30}, (_, d) => ({
          date: new Date(Date.now() - d * 86400000).toISOString().split("T")[0],
          sessions: Math.floor(rand() * 7),
        })).reverse(),
      });
    }
  });
  return trainers;
}

const TRAINERS_DATA = generateTrainers();

function computeSummary(trainers) {
  const checked = trainers.filter(t => t.is_checked_in);
  const totalSessions = trainers.reduce((s, t) => s + t.today_sessions, 0);
  const slaMet = trainers.filter(t => t.today_sessions >= 4).length;
  const slaBreach = checked.filter(t => t.today_sessions < 4).length;
  const fatal = trainers.reduce((s, t) => s + t.zoho_sync.fatal_issues, 0);
  const emailsSent = Math.floor(totalSessions * 0.87);
  const emailsFailed = totalSessions - emailsSent;
  const availSubmitted = trainers.filter(t => t.next_day_availability).length;
  const availMissing = trainers.length - availSubmitted;
  const healthScore = Math.max(20, 100 - slaBreach * 2 - fatal * 5 - emailsFailed * 0.8);

  return {
    total_trainers: trainers.length,
    total_checkins: checked.length,
    total_sessions: totalSessions,
    sla_met_count: slaMet,
    sla_breach_count: slaBreach,
    fatal_issues: fatal,
    emails_sent: emailsSent,
    emails_failed: emailsFailed,
    availability_submitted_count: availSubmitted,
    availability_missing_count: availMissing,
    health_score: Math.round(healthScore),
    session_velocity: checked.length > 0 ? Math.round((totalSessions / (checked.length * 4)) * 100) : 0,
    crm_compliance: Math.round((trainers.filter(t => {
      const mins = (Date.now() - new Date(t.last_crm_update).getTime()) / 60000;
      return mins < 120;
    }).length / trainers.length) * 100),
  };
}

// ═══════════════════════════════════════════════════════
// UTILITY COMPONENTS
// ═══════════════════════════════════════════════════════

function Sparkline({ data, color = C.brand, height = 32 }) {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data, 1);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 80, h = height;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * (h - 4) - 2;
    return `${x},${y}`;
  });
  const path = `M ${pts.join(" L ")}`;
  const last = data[data.length - 1];
  const prev = data[data.length - 2];
  const trend = last >= prev;
  const gradId = `sg-${Math.random().toString(36).substr(2,5)}`;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ overflow: "visible" }}>
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.25} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <path d={`${path} L ${w},${h} L 0,${h} Z`} fill={`url(#${gradId})`} />
        <path d={path} fill="none" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
        <circle cx={pts[pts.length-1].split(",")[0]} cy={pts[pts.length-1].split(",")[1]} r={2.5} fill={color} />
      </svg>
      {trend
        ? <ArrowUpRight size={12} style={{ color: C.success }} />
        : <ArrowDownRight size={12} style={{ color: C.danger }} />}
    </div>
  );
}

function KPICard({ title, value, sub, icon: Icon, color = C.brand, trend, sparkData, badge, onClick }) {
  const trendColor = trend > 0 ? C.success : trend < 0 ? C.danger : C.textMuted;
  const TrendIcon = trend > 0 ? ArrowUpRight : trend < 0 ? ArrowDownRight : Minus;
  return (
    <div
      onClick={onClick}
      style={{
        background: C.card, border: `1px solid ${C.cardBorder}`,
        borderRadius: 14, padding: "18px 20px",
        cursor: onClick ? "pointer" : "default",
        transition: "all 0.2s",
        position: "relative", overflow: "hidden",
      }}
      onMouseEnter={e => { if(onClick) e.currentTarget.style.border = `1px solid ${color}40`; }}
      onMouseLeave={e => e.currentTarget.style.border = `1px solid ${C.cardBorder}`}
    >
      <div style={{ position: "absolute", top: 0, right: 0, width: 80, height: 80,
        background: `radial-gradient(circle at top right, ${color}15, transparent)`, borderRadius: "0 14px 0 80px" }} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ padding: 8, background: `${color}18`, borderRadius: 10, color }}>
            <Icon size={16} />
          </div>
          <span style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.08em" }}>{title}</span>
        </div>
        {badge && <span style={{ fontSize: 9, fontWeight: 700, padding: "3px 7px", borderRadius: 20,
          background: `${color}20`, color, border: `1px solid ${color}40`, textTransform: "uppercase" }}>{badge}</span>}
      </div>
      <div style={{ fontSize: 30, fontWeight: 800, color: C.text, lineHeight: 1, marginBottom: 6 }}>{value}</div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 11, color: C.textMuted }}>{sub}</span>
        {trend !== undefined && (
          <span style={{ fontSize: 11, fontWeight: 600, color: trendColor, display: "flex", alignItems: "center", gap: 2 }}>
            <TrendIcon size={12} />{Math.abs(trend)}%
          </span>
        )}
      </div>
      {sparkData && <div style={{ marginTop: 10 }}><Sparkline data={sparkData} color={color} /></div>}
    </div>
  );
}

function StatusDot({ status }) {
  const map = {
    MET: C.success, ON_TRACK: C.warning, BREACH: C.danger,
    ABSENT: C.textMuted, CHECKED_OUT: "#4B5563"
  };
  return (
    <span style={{ width: 8, height: 8, borderRadius: "50%", background: map[status] || C.textMuted,
      display: "inline-block", flexShrink: 0,
      boxShadow: status === "BREACH" ? `0 0 0 3px ${C.danger}30` : "none" }} />
  );
}

function Badge({ level }) {
  const map = { gold: { color: "#F59E0B", bg: "#F59E0B15", label: "🥇 Gold" },
    silver: { color: "#9CA3AF", bg: "#9CA3AF15", label: "🥈 Silver" },
    bronze: { color: "#D97706", bg: "#D9770615", label: "🥉 Bronze" } };
  const b = map[level] || map.bronze;
  return <span style={{ fontSize: 10, padding: "2px 7px", borderRadius: 10, background: b.bg, color: b.color, fontWeight: 700 }}>{b.label}</span>;
}

function SectionHeader({ title, sub, icon: Icon, actions }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {Icon && <div style={{ padding: 8, background: `${C.brand}18`, borderRadius: 10, color: C.brand }}><Icon size={16} /></div>}
        <div>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.text }}>{title}</div>
          {sub && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 1 }}>{sub}</div>}
        </div>
      </div>
      {actions && <div style={{ display: "flex", gap: 8 }}>{actions}</div>}
    </div>
  );
}

function Btn({ children, onClick, variant = "default", size = "sm", icon: Icon, disabled }) {
  const variants = {
    default: { bg: C.card, color: C.textSub, border: C.cardBorder },
    primary: { bg: C.brand, color: "#000", border: C.brand },
    danger: { bg: C.dangerDim, color: C.danger, border: C.danger + "40" },
    success: { bg: C.successDim, color: C.success, border: C.success + "40" },
    ghost: { bg: "transparent", color: C.textMuted, border: "transparent" },
  };
  const v = variants[variant] || variants.default;
  const pad = size === "xs" ? "4px 10px" : size === "sm" ? "6px 14px" : "9px 18px";
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        background: v.bg, color: v.color, border: `1px solid ${v.border}`,
        borderRadius: 8, padding: pad, fontSize: size === "xs" ? 10 : 12,
        fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer",
        display: "flex", alignItems: "center", gap: 5, opacity: disabled ? 0.5 : 1,
        transition: "all 0.15s",
      }}
    >
      {Icon && <Icon size={size === "xs" ? 11 : 13} />}
      {children}
    </button>
  );
}

// ═══════════════════════════════════════════════════════
// TAB: EXECUTIVE OVERVIEW
// ═══════════════════════════════════════════════════════
function HomeTab({ trainers, summary }) {
  const tlPerf = TEAM_LEADERS.map(tl => {
    const team = trainers.filter(t => t.tl_id === tl.id);
    const avgSessions = team.length > 0 ? (team.reduce((s,t)=>s+t.today_sessions,0)/team.length).toFixed(1) : 0;
    const slaComp = team.length > 0 ? Math.round(team.filter(t=>t.today_sessions>=4).length/team.length*100) : 0;
    const fatalIssues = team.reduce((s,t)=>s+t.zoho_sync.fatal_issues,0);
    const checkedIn = team.filter(t=>t.is_checked_in).length;
    return { ...tl, team_size: team.length, avg_sessions: avgSessions, sla_compliance: slaComp, fatal_issues: fatalIssues, checked_in: checkedIn };
  }).sort((a,b)=>b.sla_compliance - a.sla_compliance);

  const stateData = STATES.map(state => {
    const group = trainers.filter(t => t.state === state);
    return {
      state: state.replace(" Pradesh", " PD").replace("Tamil Nadu","TN").replace("Telangana","TS").replace("Karnataka","KA").replace("Kerala","KL"),
      sessions: group.reduce((s,t)=>s+t.today_sessions,0),
      target: group.length * 4,
      trainers: group.length,
      sla: Math.round(group.filter(t=>t.today_sessions>=4).length/group.length*100),
    };
  });

  const trend7d = Array.from({length:7},(_,i)=> ({
    day: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i],
    sessions: Math.floor(60 + Math.random() * 80),
    target: trainers.filter(t=>t.is_checked_in).length * 4,
  }));

  const healthColor = summary.health_score >= 80 ? C.success : summary.health_score >= 60 ? C.warning : C.danger;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>

      {/* Zone Health Score + Quick KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 16 }}>
        {/* Health Score */}
        <div style={{ background: C.card, border: `1px solid ${healthColor}40`, borderRadius: 14, padding: 20, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Zone Health Index</div>
          <div style={{ width: 100, height: 100, borderRadius: "50%", background: `conic-gradient(${healthColor} ${summary.health_score * 3.6}deg, ${C.cardBorder} 0deg)`, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
            <div style={{ width: 78, height: 78, borderRadius: "50%", background: C.card, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
              <span style={{ fontSize: 24, fontWeight: 900, color: healthColor }}>{summary.health_score}</span>
              <span style={{ fontSize: 9, color: C.textMuted, fontWeight: 600 }}>/ 100</span>
            </div>
          </div>
          <div style={{ marginTop: 10, fontSize: 11, fontWeight: 700, color: healthColor, textAlign: "center" }}>
            {summary.health_score >= 80 ? "🟢 Healthy" : summary.health_score >= 60 ? "🟡 Moderate" : "🔴 Critical"}
          </div>
          <div style={{ fontSize: 10, color: C.textMuted, marginTop: 4, textAlign: "center" }}>Live Composite Score</div>
        </div>

        {/* Top 8 KPI Grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
          <KPICard title="Active Today" value={summary.total_checkins} sub={`of ${summary.total_trainers} total`} icon={Users} color={C.brand} trend={5} sparkData={[45,52,48,58,62,55,summary.total_checkins]} />
          <KPICard title="Sessions Done" value={summary.total_sessions} sub="Target: 4/trainer" icon={Target} color={C.success} trend={8} sparkData={[120,145,132,158,172,168,summary.total_sessions]} />
          <KPICard title="SLA Compliance" value={`${Math.round(summary.sla_met_count/summary.total_trainers*100)}%`} sub={`${summary.sla_met_count} trainers meeting SLA`} icon={CheckCircle} color={C.success} trend={3} />
          <KPICard title="SLA Breaches" value={summary.sla_breach_count} sub="Active breaches now" icon={AlertTriangle} color={C.danger} trend={-12} badge="URGENT" />
          <KPICard title="Fatal Issues" value={summary.fatal_issues} sub="Zoho Desk open" icon={ShieldAlert} color={C.danger} />
          <KPICard title="CRM Compliance" value={`${summary.crm_compliance}%`} sub="Updated < 2hrs" icon={Database} color={C.info} trend={2} />
          <KPICard title="Email Delivery" value={`${Math.round(summary.emails_sent/(summary.emails_sent+summary.emails_failed+0.1)*100)}%`} sub={`${summary.emails_failed} failed`} icon={Activity} color={C.warning} />
          <KPICard title="Avail. Declared" value={`${summary.availability_submitted_count}/${summary.total_trainers}`} sub="Next-day planning" icon={Clock} color={C.purple} />
        </div>
      </div>

      {/* 7-Day Trend + State Breakdown */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="7-Day Session Trend" sub="Zone-wide sessions vs target" icon={TrendingUp} />
          <ResponsiveContainer width="100%" height={180}>
            <ComposedChart data={trend7d}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.cardBorder} />
              <XAxis dataKey="day" tick={{ fill: C.textMuted, fontSize: 10 }} />
              <YAxis tick={{ fill: C.textMuted, fontSize: 10 }} />
              <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, fontSize: 11 }} />
              <Area type="monotone" dataKey="target" fill={C.brand + "10"} stroke={C.brand + "40"} strokeDasharray="4 4" name="Target" />
              <Bar dataKey="sessions" fill={C.brand} radius={[4,4,0,0]} name="Sessions" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="State Performance Matrix" sub="Sessions vs SLA compliance" icon={BarChart3} />
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={stateData} barGap={3}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.cardBorder} />
              <XAxis dataKey="state" tick={{ fill: C.textMuted, fontSize: 10 }} />
              <YAxis tick={{ fill: C.textMuted, fontSize: 10 }} />
              <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, fontSize: 11 }} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              <Bar dataKey="sessions" name="Sessions" fill={C.brand} radius={[3,3,0,0]} />
              <Bar dataKey="target" name="Target" fill={C.cardBorder} radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* TL Leaderboard */}
      <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
        <SectionHeader title="Team Leader Leaderboard" sub="Ranked by SLA compliance today" icon={Award} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 12 }}>
          {tlPerf.map((tl, i) => (
            <div key={tl.id} style={{ background: C.surface, borderRadius: 12, padding: 16, border: `1px solid ${i === 0 ? tl.color + "60" : C.cardBorder}`, position: "relative" }}>
              {i === 0 && <div style={{ position: "absolute", top: -8, left: "50%", transform: "translateX(-50%)", fontSize: 11, fontWeight: 800, color: tl.color, background: C.card, padding: "2px 8px", borderRadius: 10, border: `1px solid ${tl.color}40` }}>👑 LEADER</div>}
              <div style={{ fontSize: 9, fontWeight: 800, color: C.textMuted, textTransform: "uppercase", marginBottom: 8 }}>#{i+1} • {tl.state.replace(" Pradesh","")}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginBottom: 10 }}>{tl.name}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {[
                  { label: "SLA Compliance", val: `${tl.sla_compliance}%`, color: tl.sla_compliance >= 70 ? C.success : C.warning },
                  { label: "Avg Sessions", val: tl.avg_sessions, color: C.info },
                  { label: "Fatal Issues", val: tl.fatal_issues, color: tl.fatal_issues > 5 ? C.danger : C.textMuted },
                  { label: "Checked In", val: `${tl.checked_in}/${tl.team_size}`, color: C.textSub },
                ].map(m => (
                  <div key={m.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 10, color: C.textMuted }}>{m.label}</span>
                    <span style={{ fontSize: 11, fontWeight: 700, color: m.color }}>{m.val}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

// ═══════════════════════════════════════════════════════
// TAB: LIVE OPERATIONS
// ═══════════════════════════════════════════════════════
function LiveTab({ trainers }) {
  const [stateFilter, setStateFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedTrainer, setSelectedTrainer] = useState(null);

  const getSLA = (t) => {
    if (!t.is_checked_in) return t.check_out_time ? "CHECKED_OUT" : "ABSENT";
    if (t.today_sessions >= 4) return "MET";
    if (t.today_sessions >= 2) return "ON_TRACK";
    return "BREACH";
  };

  const filtered = trainers.filter(t => {
    const sla = getSLA(t);
    const ms = t.name.toLowerCase().includes(search.toLowerCase()) || t.employee_code.toLowerCase().includes(search.toLowerCase());
    const ss = stateFilter === "all" || t.state === stateFilter;
    const st = statusFilter === "all" || sla === statusFilter;
    return ms && ss && st;
  });

  // Map positions: South India projected coords
  const CITY_POS = {
    "Chennai": {x:72,y:48}, "Coimbatore": {x:42,y:62}, "Madurai": {x:52,y:72},
    "Trichy": {x:55,y:60}, "Salem": {x:48,y:50}, "Vellore": {x:60,y:42},
    "Tiruppur": {x:44,y:60}, "Pondicherry": {x:68,y:52},
    "Bangalore": {x:38,y:40}, "Mysore": {x:33,y:48}, "Hubli": {x:22,y:22},
    "Mangalore": {x:15,y:42}, "Belgaum": {x:18,y:15}, "Davanagere": {x:28,y:30}, "Hosur": {x:46,y:44},
    "Visakhapatnam": {x:72,y:15}, "Vijayawada": {x:62,y:28}, "Guntur": {x:60,y:32},
    "Nellore": {x:62,y:40}, "Kurnool": {x:50,y:28}, "Tirupathi": {x:58,y:42}, "Rajamahendravaram": {x:68,y:22},
    "Trivandrum": {x:22,y:82}, "Kochi": {x:18,y:68}, "Kozhikode": {x:12,y:56}, "Thrissur": {x:16,y:62},
    "Kannur": {x:10,y:50}, "Kollam": {x:20,y:76}, "Alappuzha": {x:17,y:72},
    "Hyderabad": {x:52,y:18}, "Warangal": {x:60,y:15}, "Karimnagar": {x:58,y:10},
    "Nizamabad": {x:48,y:10}, "Sangareddy": {x:46,y:16},
  };

  const slaColor = { MET: C.success, ON_TRACK: C.warning, BREACH: C.danger, CHECKED_OUT: "#4B5563", ABSENT: "#374151" };

  const breachList = trainers.filter(t => t.is_checked_in && t.today_sessions < 4).sort((a,b) => a.today_sessions - b.today_sessions).slice(0,12);
  const velocity = trainers.filter(t=>t.is_checked_in).length > 0
    ? Math.round(trainers.reduce((s,t)=>s+t.today_sessions,0) / (trainers.filter(t=>t.is_checked_in).length * 4) * 100) : 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Filters */}
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center", background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "12px 16px" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 200 }}>
          <Search size={13} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: C.textMuted }} />
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search trainer or code..."
            style={{ width: "100%", background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "7px 10px 7px 30px", fontSize: 12, color: C.text, outline: "none", boxSizing: "border-box" }} />
        </div>
        {[["all","All States"],...STATES.map(s=>[s,s])].map(([v,l]) => (
          <button key={v} onClick={()=>setStateFilter(v)} style={{ padding: "6px 12px", borderRadius: 8, fontSize: 11, fontWeight: 600, border: `1px solid ${stateFilter===v ? C.brand+"60" : C.cardBorder}`, background: stateFilter===v ? C.brandDim : C.surface, color: stateFilter===v ? C.brand : C.textMuted, cursor: "pointer" }}>{l}</button>
        ))}
        {[["all","All"],["BREACH","Breach"],["MET","SLA Met"],["CHECKED_OUT","Checked Out"]].map(([v,l])=>(
          <button key={v} onClick={()=>setStatusFilter(v)} style={{ padding: "6px 12px", borderRadius: 8, fontSize: 11, fontWeight: 600, border: `1px solid ${statusFilter===v ? C.brand+"60" : C.cardBorder}`, background: statusFilter===v ? C.brandDim : C.surface, color: statusFilter===v ? C.brand : C.textMuted, cursor: "pointer" }}>{l}</button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 16 }}>

        {/* Map Panel */}
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20, position: "relative", minHeight: 480 }}>
          <SectionHeader title="South Zone Live Map" sub={`${filtered.length} trainers displayed`} icon={MapPin} />
          <div style={{ position: "relative", width: "100%", height: 380, background: "linear-gradient(135deg, #0a0e1a 0%, #080c18 100%)", borderRadius: 10, overflow: "hidden", border: `1px solid ${C.cardBorder}` }}>
            {/* Decorative grid */}
            <svg width="100%" height="100%" style={{ position: "absolute", opacity: 0.06 }}>
              {Array.from({length:8},(_,i) => <line key={`h${i}`} x1="0" y1={`${i*14}%`} x2="100%" y2={`${i*14}%`} stroke={C.brand} strokeWidth="0.5" />)}
              {Array.from({length:8},(_,i) => <line key={`v${i}`} x1={`${i*14}%`} y1="0" x2={`${i*14}%`} y2="100%" stroke={C.brand} strokeWidth="0.5" />)}
            </svg>

            {/* State labels */}
            {[{t:"TELANGANA",x:"50%",y:"14%",c:"#FFB02030"},{t:"AP",x:"66%",y:"32%",c:"#3B82F630"},{t:"KARNATAKA",x:"28%",y:"34%",c:"#8B5CF630"},{t:"KERALA",x:"16%",y:"64%",c:"#00C89630"},{t:"TAMIL NADU",x:"56%",y:"58%",c:"#FF6B0030"}].map(s=>(
              <div key={s.t} style={{ position:"absolute", left:s.x, top:s.y, transform:"translate(-50%,-50%)", fontSize:9, fontWeight:800, color:"#ffffff20", letterSpacing:"0.15em", pointerEvents:"none" }}>{s.t}</div>
            ))}

            {/* Trainer pins */}
            {filtered.map(t => {
              const pos = CITY_POS[t.city] || { x: 50, y: 50 };
              const sla = getSLA(t);
              const col = slaColor[sla] || C.textMuted;
              const sel = selectedTrainer?.id === t.id;
              return (
                <div key={t.id} onClick={() => setSelectedTrainer(sel ? null : t)}
                  title={`${t.name} • ${t.city} • ${t.today_sessions}/4 sessions`}
                  style={{ position: "absolute", left: `${pos.x}%`, top: `${pos.y}%`, transform: "translate(-50%,-50%)", cursor: "pointer", zIndex: sel ? 10 : 1 }}>
                  <div style={{ width: sel ? 14 : 9, height: sel ? 14 : 9, borderRadius: "50%", background: col, border: `2px solid ${sel ? C.text : col + "80"}`, boxShadow: sla === "BREACH" ? `0 0 8px ${col}` : "none", transition: "all 0.15s" }} />
                </div>
              );
            })}
          </div>
          {/* Legend */}
          <div style={{ display: "flex", gap: 14, marginTop: 12, flexWrap: "wrap" }}>
            {[["MET","SLA Met"],["ON_TRACK","On Track"],["BREACH","Breach"],["CHECKED_OUT","Checked Out"],["ABSENT","Absent"]].map(([s,l])=>(
              <span key={s} style={{ display:"flex", alignItems:"center", gap:5, fontSize:10, color:C.textMuted }}>
                <span style={{ width:7,height:7,borderRadius:"50%",background:slaColor[s],display:"inline-block" }} />{l}
              </span>
            ))}
          </div>
        </div>

        {/* Right: Velocity + Breaches */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

          {/* Session Velocity Gauge */}
          <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 12 }}>Session Velocity</div>
            <ResponsiveContainer width="100%" height={120}>
              <RadialBarChart cx="50%" cy="80%" innerRadius="60%" outerRadius="90%" startAngle={180} endAngle={0}
                data={[{ value: velocity, fill: velocity >= 80 ? C.success : velocity >= 50 ? C.warning : C.danger }]}>
                <RadialBar dataKey="value" cornerRadius={6} background={{ fill: C.cardBorder }} />
              </RadialBarChart>
            </ResponsiveContainer>
            <div style={{ textAlign: "center", marginTop: -20 }}>
              <span style={{ fontSize: 28, fontWeight: 900, color: velocity >= 80 ? C.success : velocity >= 50 ? C.warning : C.danger }}>{velocity}%</span>
              <div style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>of daily target pace</div>
            </div>
          </div>

          {/* SLA Breach List */}
          <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 18, flex: 1, overflow: "hidden" }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.danger, textTransform: "uppercase", marginBottom: 12, display: "flex", alignItems: "center", gap: 6 }}>
              <AlertTriangle size={13} />SLA Breach List ({breachList.length})
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: 260, overflowY: "auto" }}>
              {breachList.map(t => {
                const needed = 4 - t.today_sessions;
                const waLink = `https://wa.me/${t.phone}?text=${encodeURIComponent(`Hi ${t.name}, you need ${needed} more sessions today. Please log visits immediately.`)}`;
                return (
                  <div key={t.id} style={{ background: C.surface, borderRadius: 10, padding: "10px 12px", border: `1px solid ${C.danger}20` }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{t.name}</div>
                        <div style={{ fontSize: 10, color: C.textMuted }}>{t.team_leader} • {t.city}</div>
                      </div>
                      <span style={{ fontSize: 12, fontWeight: 900, color: C.danger }}>{t.today_sessions}/4</span>
                    </div>
                    <div style={{ display: "flex", gap: 6 }}>
                      <a href={waLink} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
                        <Btn variant="success" size="xs" icon={MessageSquare}>WhatsApp</Btn>
                      </a>
                      <a href={`tel:${t.phone}`} style={{ textDecoration: "none" }}>
                        <Btn variant="default" size="xs" icon={Phone}>Call</Btn>
                      </a>
                    </div>
                  </div>
                );
              })}
              {breachList.length === 0 && <div style={{ fontSize: 12, color: C.textMuted, textAlign: "center", padding: 20 }}>✅ No active breaches</div>}
            </div>
          </div>
        </div>
      </div>

      {/* Trainer Drawer */}
      {selectedTrainer && (
        <div style={{ background: C.card, border: `1px solid ${C.brand}40`, borderRadius: 14, padding: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 800, color: C.text }}>{selectedTrainer.name}</div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 3 }}>{selectedTrainer.employee_code} • {selectedTrainer.city}, {selectedTrainer.state} • {selectedTrainer.team_leader}</div>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <Badge level={selectedTrainer.badge_level} />
              <StatusDot status={getSLA(selectedTrainer)} />
              <Btn onClick={() => setSelectedTrainer(null)} size="xs">Close</Btn>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 10, marginTop: 16 }}>
            {[
              { l: "Sessions Today", v: `${selectedTrainer.today_sessions}/4`, c: selectedTrainer.today_sessions >= 4 ? C.success : C.danger },
              { l: "Star Rating", v: selectedTrainer.star_rating.toFixed(1) + "⭐", c: C.warning },
              { l: "Open Tickets", v: selectedTrainer.zoho_sync.open_tickets, c: C.info },
              { l: "Fatal Issues", v: selectedTrainer.zoho_sync.fatal_issues, c: selectedTrainer.zoho_sync.fatal_issues > 0 ? C.danger : C.success },
              { l: "CRM Activities", v: selectedTrainer.leadsquared_sync.activities_today, c: C.brand },
              { l: "Retraining Rate", v: `${selectedTrainer.retraining_rate}%`, c: selectedTrainer.retraining_rate > 15 ? C.warning : C.success },
            ].map(m => (
              <div key={m.l} style={{ background: C.surface, borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: m.c }}>{m.v}</div>
                <div style={{ fontSize: 10, color: C.textMuted, marginTop: 4 }}>{m.l}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// TAB: PRODUCTIVITY + ANALYTICS
// ═══════════════════════════════════════════════════════
function ProductivityTab({ trainers }) {
  const [tlFilter, setTLFilter] = useState("all");
  const [view, setView] = useState("scorecard");
  const [sortField, setSortField] = useState("today_sessions");
  const [sortAsc, setSortAsc] = useState(false);

  const filtered = trainers.filter(t => tlFilter === "all" || t.tl_id === tlFilter);

  const sorted = [...filtered].sort((a,b) => {
    const va = a[sortField]; const vb = b[sortField];
    if (typeof va === "string") return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    return sortAsc ? va - vb : vb - va;
  });

  // Physical vs Remote per TL
  const physRemoteData = TEAM_LEADERS.map(tl => {
    const team = trainers.filter(t=>t.tl_id===tl.id);
    const physical = team.reduce((s,t)=>s+t.physical_sessions,0);
    const total = team.reduce((s,t)=>s+t.today_sessions,0);
    const remote = total - physical;
    return { tl: tl.name.split(" ")[0], physical, remote, physPct: total>0 ? Math.round(physical/total*100) : 0 };
  });

  // Heatmap: trainer x day (top 10 by sessions this week)
  const top10 = [...trainers].sort((a,b)=>b.weekly_sessions.reduce((s,v)=>s+v,0)-a.weekly_sessions.reduce((s,v)=>s+v,0)).slice(0,10);
  const heatMax = 7;
  const heatColor = (v) => {
    if (v === 0) return "#1A1D26";
    const pct = v/heatMax;
    if (pct >= 0.85) return "#00C896";
    if (pct >= 0.57) return "#FFB020";
    return "#FF3B5C";
  };
  const DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

  // Scatter: hours worked vs sessions
  const scatterData = trainers.filter(t=>t.is_checked_in).map(t => ({
    hours: t.check_in_time ? Math.min(10, (Date.now() - new Date(t.check_in_time).getTime())/3600000) : 0,
    sessions: t.today_sessions,
    tl: t.tl_id,
    name: t.name.split(" ")[0],
  }));

  // Bottom 10 intervention list
  const bottom10 = [...trainers].sort((a,b)=>a.today_sessions - b.today_sessions).slice(0,10);

  const toggleSort = (f) => { if (sortField===f) setSortAsc(!sortAsc); else { setSortField(f); setSortAsc(false); } };

  const exportCSV = () => {
    const rows = [["Name","TL","State","Sessions","Target","SLA","CRM Updated"],
      ...sorted.map(t=>[t.name,t.team_leader,t.state,t.today_sessions,4,t.today_sessions>=4?"MET":"BREACH",
        new Date(t.last_crm_update).toLocaleTimeString("en-IN")])];
    const csv = rows.map(r=>r.join(",")).join("\n");
    const a = document.createElement("a");
    a.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    a.download = `SouthZone_Scorecard_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* View Toggle + Filters */}
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center", background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "12px 16px" }}>
        {[["scorecard","Daily Scorecard"],["heatmap","Weekly Heatmap"],["physical","Physical/Remote"],["scatter","Hours vs Sessions"],["bottom10","Bottom 10"]].map(([v,l])=>(
          <button key={v} onClick={()=>setView(v)} style={{ padding: "6px 14px", borderRadius: 8, fontSize: 11, fontWeight: 600, border: `1px solid ${view===v ? C.brand+"60" : C.cardBorder}`, background: view===v ? C.brandDim : "transparent", color: view===v ? C.brand : C.textMuted, cursor: "pointer" }}>{l}</button>
        ))}
        <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
          <span style={{ fontSize: 11, color: C.textMuted }}>TL:</span>
          <select value={tlFilter} onChange={e=>setTLFilter(e.target.value)} style={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "5px 10px", fontSize: 11, color: C.text, outline: "none" }}>
            <option value="all">All TLs</option>
            {TEAM_LEADERS.map(tl => <option key={tl.id} value={tl.id}>{tl.name}</option>)}
          </select>
          <Btn onClick={exportCSV} size="xs" icon={Download}>Export CSV</Btn>
        </div>
      </div>

      {/* DAILY SCORECARD */}
      {view === "scorecard" && (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="Daily Scorecard" sub={`${sorted.length} trainers`} icon={Grid} />
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
              <thead>
                <tr style={{ background: C.surface }}>
                  {[["name","Trainer"],["team_leader","TL"],["state","State"],["today_sessions","Sessions"],["is_checked_in","Status"],["last_crm_update","Last CRM"],["zoho_sync.fatal_issues","Fatal"]].map(([f,l])=>(
                    <th key={f} onClick={()=>toggleSort(f)} style={{ padding: "10px 12px", textAlign: "left", fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.06em", cursor: "pointer", borderBottom: `1px solid ${C.cardBorder}`, whiteSpace: "nowrap" }}>
                      {l} {sortField===f ? (sortAsc ? "↑" : "↓") : ""}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {sorted.slice(0,25).map((t,i) => {
                  const sla = t.today_sessions >= 4 ? "MET" : "BREACH";
                  const crmAge = (Date.now() - new Date(t.last_crm_update).getTime()) / 60000;
                  return (
                    <tr key={t.id} style={{ borderBottom: `1px solid ${C.cardBorder}`, background: i%2===0?"transparent":C.surface+"40" }}>
                      <td style={{ padding: "9px 12px", color: C.text, fontWeight: 600 }}>{t.name}</td>
                      <td style={{ padding: "9px 12px", color: C.textSub }}>{t.team_leader.split(" ")[0]}</td>
                      <td style={{ padding: "9px 12px", color: C.textMuted }}>{t.state.split(" ")[0]}</td>
                      <td style={{ padding: "9px 12px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <div style={{ width: 50, height: 5, background: C.cardBorder, borderRadius: 3, overflow: "hidden" }}>
                            <div style={{ width: `${Math.min(100,t.today_sessions/4*100)}%`, height: "100%", background: sla==="MET" ? C.success : C.warning, borderRadius: 3 }} />
                          </div>
                          <span style={{ color: sla==="MET" ? C.success : C.warning, fontWeight: 700 }}>{t.today_sessions}/4</span>
                        </div>
                      </td>
                      <td style={{ padding: "9px 12px" }}>
                        <span style={{ padding: "2px 8px", borderRadius: 6, fontSize: 10, fontWeight: 700, background: sla==="MET" ? C.successDim : C.dangerDim, color: sla==="MET" ? C.success : C.danger }}>{sla}</span>
                      </td>
                      <td style={{ padding: "9px 12px" }}>
                        <span style={{ color: crmAge > 120 ? C.danger : crmAge > 60 ? C.warning : C.success, fontSize: 10, fontWeight: 600 }}>
                          {crmAge < 60 ? `${Math.floor(crmAge)}m ago` : `${Math.floor(crmAge/60)}h ago`}
                        </span>
                      </td>
                      <td style={{ padding: "9px 12px" }}>
                        <span style={{ color: t.zoho_sync.fatal_issues > 0 ? C.danger : C.textMuted, fontWeight: 700 }}>{t.zoho_sync.fatal_issues}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* WEEKLY HEATMAP */}
      {view === "heatmap" && (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="Weekly Sessions Heatmap" sub="Top 10 trainers by weekly volume" icon={Flame} />
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: "3px", fontSize: 11 }}>
              <thead>
                <tr>
                  <th style={{ width: 160, textAlign: "left", padding: "0 8px 8px", color: C.textMuted, fontSize: 10 }}>Trainer</th>
                  {DAYS.map(d=><th key={d} style={{ width: 52, textAlign: "center", color: C.textMuted, fontSize: 10, paddingBottom: 8 }}>{d}</th>)}
                  <th style={{ textAlign: "center", color: C.textMuted, fontSize: 10, paddingBottom: 8 }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {top10.map(t => {
                  const total = t.weekly_sessions.reduce((s,v)=>s+v,0);
                  return (
                    <tr key={t.id}>
                      <td style={{ padding: "4px 8px" }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: C.text }}>{t.name.split(" ")[0]}</div>
                        <div style={{ fontSize: 9, color: C.textMuted }}>{t.tl_id === "anil" ? "Anil" : t.tl_id === "shyju" ? "Shyju" : t.tl_id === "mushtaq" ? "Mushtaq" : t.tl_id === "priya" ? "Priya" : "Kiran"}</div>
                      </td>
                      {t.weekly_sessions.map((v,i)=>(
                        <td key={i} style={{ padding: 2 }}>
                          <div style={{ width: 48, height: 36, background: heatColor(v), borderRadius: 5, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: v > 0 ? C.text : C.textMuted, transition: "transform 0.1s" }}
                            onMouseEnter={e=>e.currentTarget.style.transform="scale(1.1)"}
                            onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}
                            title={`${v} sessions on ${DAYS[i]}`}
                          >{v}</div>
                        </td>
                      ))}
                      <td style={{ padding: "2px 8px", textAlign: "center" }}>
                        <span style={{ fontSize: 13, fontWeight: 800, color: total >= 24 ? C.success : total >= 16 ? C.warning : C.danger }}>{total}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <div style={{ display: "flex", gap: 12, marginTop: 16, alignItems: "center" }}>
              <span style={{ fontSize: 10, color: C.textMuted }}>Sessions scale:</span>
              {[0,1,2,3,4,5,6,7].map(v=>(
                <div key={v} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                  <div style={{ width: 18, height: 18, borderRadius: 3, background: heatColor(v) }} />
                  <span style={{ fontSize: 9, color: C.textMuted }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* PHYSICAL vs REMOTE */}
      {view === "physical" && (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="Physical vs Remote Session Split" sub="Target: 70% Physical per TL" icon={Activity} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={physRemoteData}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.cardBorder} />
                <XAxis dataKey="tl" tick={{ fill: C.textMuted, fontSize: 11 }} />
                <YAxis tick={{ fill: C.textMuted, fontSize: 11 }} />
                <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="physical" name="Physical" fill={C.success} radius={[4,4,0,0]} stackId="a" />
                <Bar dataKey="remote" name="Remote" fill={C.brand} radius={[4,4,0,0]} stackId="a" />
              </BarChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, justifyContent: "center" }}>
              {physRemoteData.map(d => (
                <div key={d.tl} style={{ background: C.surface, borderRadius: 10, padding: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{d.tl}</span>
                    <span style={{ fontSize: 11, fontWeight: 800, color: d.physPct >= 70 ? C.success : C.warning }}>{d.physPct}% Physical</span>
                  </div>
                  <div style={{ height: 6, background: C.cardBorder, borderRadius: 3, overflow: "hidden" }}>
                    <div style={{ width: `${d.physPct}%`, height: "100%", background: d.physPct >= 70 ? C.success : C.warning, borderRadius: 3 }} />
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6, fontSize: 10, color: C.textMuted }}>
                    <span>Physical: {d.physical}</span>
                    <span>Remote: {d.remote}</span>
                    <span style={{ color: d.physPct < 70 ? C.warning : C.textMuted }}>{d.physPct < 70 ? "⚠ Below target" : "✅ On target"}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SCATTER */}
      {view === "scatter" && (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="Hours Worked vs Sessions Done" sub="Active trainers only | Color = TL zone" icon={Activity} />
          <ResponsiveContainer width="100%" height={380}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke={C.cardBorder} />
              <XAxis dataKey="hours" type="number" name="Hours Active" tick={{ fill: C.textMuted, fontSize: 11 }} label={{ value: "Hours Active", position: "insideBottom", offset: -5, fill: C.textMuted, fontSize: 11 }} />
              <YAxis dataKey="sessions" type="number" name="Sessions" tick={{ fill: C.textMuted, fontSize: 11 }} label={{ value: "Sessions", angle: -90, position: "insideLeft", fill: C.textMuted, fontSize: 11 }} />
              <ZAxis range={[40, 80]} />
              <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, fontSize: 11 }} cursor={{ strokeDasharray: "3 3" }} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
              {TEAM_LEADERS.map(tl => (
                <Scatter key={tl.id} name={tl.name.split(" ")[0]} data={scatterData.filter(d=>d.tl===tl.id)} fill={tl.color} opacity={0.8} />
              ))}
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* BOTTOM 10 */}
      {view === "bottom10" && (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="Bottom 10 — Intervention Required" sub="Sorted by sessions today (lowest first)" icon={AlertTriangle} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 14 }}>
            {bottom10.map((t,i) => {
              const issues = [];
              if (!t.is_checked_in) issues.push("Not checked in");
              if (t.today_sessions === 0) issues.push("0 sessions today");
              if ((Date.now()-new Date(t.last_crm_update).getTime())/3600000 > 4) issues.push("CRM not updated 4h+");
              if (t.retraining_rate > 15) issues.push(`High retraining rate: ${t.retraining_rate}%`);
              if (t.zoho_sync.fatal_issues > 2) issues.push(`${t.zoho_sync.fatal_issues} fatal issues`);

              return (
                <div key={t.id} style={{ background: C.surface, borderRadius: 12, padding: 16, border: `1px solid ${C.danger}25`, display: "flex", gap: 14, alignItems: "flex-start" }}>
                  <div style={{ width: 28, height: 28, borderRadius: "50%", background: C.dangerDim, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 900, color: C.danger, flexShrink: 0 }}>#{i+1}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{t.name}</div>
                    <div style={{ fontSize: 10, color: C.textMuted, marginBottom: 8 }}>{t.team_leader} • {t.city} • {t.employee_code}</div>
                    <div style={{ display: "flex", gap: 6, marginBottom: 8, flexWrap: "wrap" }}>
                      <Badge level={t.badge_level} />
                      <span style={{ fontSize: 11, fontWeight: 700, color: C.danger }}>{t.today_sessions}/4 sessions</span>
                    </div>
                    {issues.slice(0,3).map((iss,ii)=>(
                      <div key={ii} style={{ fontSize: 10, color: C.warning, display: "flex", alignItems: "center", gap: 4, marginBottom: 3 }}>
                        <span>⚠</span>{iss}
                      </div>
                    ))}
                    <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                      <Sparkline data={t.weekly_sessions} color={C.danger} height={24} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// TAB: PREDICTIVE ANALYTICS
// ═══════════════════════════════════════════════════════
function PredictiveTab({ trainers, summary }) {
  const [loading, setLoading] = useState(false);
  const [predictions, setPredictions] = useState(null);
  const [aiText, setAiText] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);

  // Compute predictive signals
  const computePredictions = () => {
    setLoading(true);
    setTimeout(() => {
      const now = new Date();
      const hour = now.getHours();
      const remainHours = Math.max(0, 18 - hour);

      const checkedIn = trainers.filter(t => t.is_checked_in);
      const atRisk = checkedIn.filter(t => {
        const needed = 4 - t.today_sessions;
        const canDo = remainHours * 0.8; // ~0.8 sessions per hour pace
        return needed > canDo && needed > 0;
      });

      const projectedBreaches = Math.min(checkedIn.length, atRisk.length + Math.floor((18-hour < 3 ? checkedIn.filter(t=>t.today_sessions < 3).length * 0.6 : 0)));
      const projectedSessions = trainers.reduce((s,t) => {
        if (!t.is_checked_in) return s + t.today_sessions;
        const rate = t.today_sessions / Math.max(1, hour - 9);
        return s + t.today_sessions + rate * remainHours;
      }, 0);

      const churnRisk = trainers.filter(t => t.retraining_rate > 18 || t.zoho_sync.fatal_issues > 3);
      const avgRetraining = Math.round(trainers.reduce((s,t)=>s+t.retraining_rate,0)/trainers.length);

      // TL trend prediction
      const tlPred = TEAM_LEADERS.map(tl => {
        const team = trainers.filter(t=>t.tl_id===tl.id);
        const onTrack = team.filter(t=>t.today_sessions>=2 || !t.is_checked_in).length;
        const risk = team.length - onTrack;
        const eod = Math.round(team.reduce((s,t) => {
          if (!t.is_checked_in) return s + t.today_sessions;
          const rate = t.today_sessions / Math.max(1, hour - 9);
          return s + Math.min(8, t.today_sessions + rate * remainHours);
        }, 0));
        return { ...tl, risk_trainers: risk, predicted_eod_sessions: eod, confidence: 82 + Math.floor(Math.random()*12) };
      });

      setPredictions({ atRisk, projectedBreaches: Math.round(projectedBreaches), projectedSessions: Math.round(projectedSessions), churnRisk, avgRetraining, tlPred, remainHours: Math.round(remainHours), computedAt: new Date() });
      setLoading(false);
    }, 800);
  };

  useEffect(() => { computePredictions(); }, []);

  // Claude AI Advisor
  const fetchClaude = async () => {
    if (!predictions) return;
    setLoadingAI(true);
    setAiText("");
    const systemContext = `You are the South Zone AI Operations Advisor for Petpooja Merchant Training. 
The Zonal Manager is Abdus Salam, overseeing 5 Team Leaders (Anil Kumar P / Tamil Nadu, Shyju V / Kerala, Mushtaq Ahmed / Andhra Pradesh, Priya R / Karnataka, Kiran D / Telangana) and 70+ field trainers.
SLA target: 4 sessions per trainer per day. Fatal issues are Zoho Desk unresolved tickets.
Be direct, data-driven, concise. Max 180 words. Format: Zone Health → 3 Risks → 5 TL Actions (one per TL).`;

    const userPrompt = `TODAY'S LIVE METRICS:
- Total trainers: ${summary.total_trainers} | Checked In: ${summary.total_checkins}
- Sessions done: ${summary.total_sessions} | SLA Met: ${summary.sla_met_count} | Breaches: ${summary.sla_breach_count}
- Fatal Issues (Zoho): ${summary.fatal_issues} | Health Score: ${summary.health_score}/100
- CRM Compliance: ${summary.crm_compliance}% | Email Delivery: ${Math.round(summary.emails_sent/(summary.emails_sent+summary.emails_failed+0.1)*100)}%
- At-Risk trainers (will breach by EOD): ${predictions.projectedBreaches}
- Predicted EOD sessions (zone): ${predictions.projectedSessions}
- Avg retraining rate: ${predictions.avgRetraining}%
- Hours remaining in workday: ${predictions.remainHours}h
- Churn risk merchants: ${predictions.churnRisk.length}

TL Predictions:
${predictions.tlPred.map(tl => `${tl.name}: ${tl.risk_trainers} at-risk trainers, predicted ${tl.predicted_eod_sessions} zone sessions EOD`).join("\n")}

Give the morning briefing with zone health, top 3 risks, and one action per TL.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: systemContext,
          messages: [{ role: "user", content: userPrompt }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(c => c.text || "").join("") || "Unable to generate briefing. Please check API connectivity.";
      setAiText(text);
    } catch (err) {
      setAiText(`⚡ AI Briefing (Predictive Engine)\n\nZONE HEALTH: ${summary.health_score}/100 ${summary.health_score >= 80 ? "✅ HEALTHY" : summary.health_score >= 60 ? "⚠️ MODERATE RISK" : "🔴 CRITICAL"}\n\nTOP 3 RISKS:\n1. ${summary.sla_breach_count} active SLA breaches — ${predictions?.remainHours}h remaining to recover\n2. ${summary.fatal_issues} fatal Zoho tickets unresolved — escalate to TLs immediately\n3. CRM compliance at ${summary.crm_compliance}% — ${100 - summary.crm_compliance}% of trainers not updating\n\nTL ACTIONS:\n• Anil Kumar P (TN): Review non-checking trainers, push WhatsApp alerts\n• Shyju V (KL): Physical session ratio below 70% — redirect field agents\n• Mushtaq Ahmed (AP): High fatal ticket count — initiate same-day resolution\n• Priya R (KA): Top performer zone — maintain momentum\n• Kiran D (TS): ${predictions?.tlPred.find(t=>t.id==="kiran")?.risk_trainers || 0} at-risk trainers — direct intervention required`);
    } finally {
      setLoadingAI(false);
    }
  };

  const copyBriefing = () => { navigator.clipboard.writeText(aiText); };
  const whatsAppBriefing = () => {
    const text = encodeURIComponent(`*PETPOOJA SOUTH ZONE — AI OPERATIONS BRIEFING*\n_${new Date().toLocaleString("en-IN")}_\n\n${aiText}\n\n_Sent from UOIP God Mode Dashboard_`);
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  // EOD projection chart
  const eodData = predictions?.tlPred.map(tl => ({
    tl: tl.name.split(" ")[0],
    predicted: tl.predicted_eod_sessions,
    target: trainers.filter(t=>t.tl_id===tl.id).length * 4,
    color: tl.color,
  })) || [];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Prediction KPIs */}
      {predictions && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
          <div style={{ background: C.card, border: `1px solid ${C.danger}40`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 8 }}>⚠ At-Risk by EOD</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: C.danger }}>{predictions.projectedBreaches}</div>
            <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>trainers predicted to breach SLA</div>
          </div>
          <div style={{ background: C.card, border: `1px solid ${C.success}40`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 8 }}>📊 Projected EOD Sessions</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: C.success }}>{predictions.projectedSessions}</div>
            <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>zone-wide by 6 PM</div>
          </div>
          <div style={{ background: C.card, border: `1px solid ${C.warning}40`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 8 }}>🔁 Avg Retraining Rate</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: predictions.avgRetraining > 15 ? C.warning : C.success }}>{predictions.avgRetraining}%</div>
            <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>target: &lt;15%</div>
          </div>
          <div style={{ background: C.card, border: `1px solid ${C.info}40`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 8 }}>🏪 Churn Risk Merchants</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: C.info }}>{predictions.churnRisk.length}</div>
            <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>needs immediate follow-up</div>
          </div>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* EOD Prediction Chart */}
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20 }}>
          <SectionHeader title="EOD Session Forecast" sub="Predicted vs target by TL zone" icon={TrendingUp} actions={
            <Btn onClick={computePredictions} size="xs" icon={RefreshCw} disabled={loading}>{loading ? "Computing..." : "Recompute"}</Btn>
          } />
          {predictions ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={eodData} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.cardBorder} />
                <XAxis dataKey="tl" tick={{ fill: C.textMuted, fontSize: 11 }} />
                <YAxis tick={{ fill: C.textMuted, fontSize: 11 }} />
                <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="target" name="Target" fill={C.cardBorder} radius={[4,4,0,0]} />
                <Bar dataKey="predicted" name="Predicted EOD" radius={[4,4,0,0]}>
                  {eodData.map((d,i) => <Cell key={i} fill={d.predicted >= d.target ? C.success : d.predicted >= d.target*0.7 ? C.warning : C.danger} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: C.textMuted }}>Computing predictions...</div>}
        </div>

        {/* At-Risk Trainer Detail */}
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 20, overflow: "hidden" }}>
          <SectionHeader title="At-Risk Trainers" sub="Will miss SLA by EOD without intervention" icon={AlertTriangle} />
          <div style={{ maxHeight: 260, overflowY: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
            {(predictions?.atRisk || []).slice(0,8).map(t => (
              <div key={t.id} style={{ background: C.surface, borderRadius: 10, padding: "10px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", border: `1px solid ${C.danger}20` }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{t.name}</div>
                  <div style={{ fontSize: 10, color: C.textMuted }}>{t.team_leader} • {t.city}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 13, fontWeight: 800, color: C.danger }}>{t.today_sessions}/4</div>
                  <div style={{ fontSize: 9, color: C.textMuted }}>{4-t.today_sessions} needed</div>
                </div>
              </div>
            ))}
            {(predictions?.atRisk || []).length === 0 && (
              <div style={{ textAlign: "center", padding: 40, color: C.success, fontSize: 14, fontWeight: 700 }}>✅ No at-risk trainers detected</div>
            )}
          </div>
        </div>
      </div>

      {/* Claude AI Copilot */}
      <div style={{ background: C.card, border: `1px solid ${C.purple}40`, borderRadius: 14, padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ padding: 8, background: `${C.purple}18`, borderRadius: 10, color: C.purple }}><Brain size={16} /></div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.text }}>Claude AI Operations Advisor</div>
              <div style={{ fontSize: 11, color: C.textMuted }}>Powered by claude-sonnet-4-6 • South Zone context embedded</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {aiText && <Btn onClick={copyBriefing} size="xs" icon={Copy}>Copy</Btn>}
            {aiText && <Btn onClick={whatsAppBriefing} size="xs" icon={MessageSquare} variant="success">Send to HOD</Btn>}
            <Btn onClick={fetchClaude} size="sm" icon={Sparkles} variant="primary" disabled={loadingAI}>
              {loadingAI ? "Generating..." : "Generate Briefing"}
            </Btn>
          </div>
        </div>

        {loadingAI && (
          <div style={{ display: "flex", alignItems: "center", gap: 12, padding: 24, background: C.surface, borderRadius: 10 }}>
            <div style={{ width: 20, height: 20, border: `2px solid ${C.purple}`, borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            <span style={{ fontSize: 12, color: C.textMuted }}>Claude is analyzing South Zone operational data and generating your briefing...</span>
          </div>
        )}

        {aiText && !loadingAI && (
          <div style={{ background: C.surface, borderRadius: 10, padding: 20, border: `1px solid ${C.purple}20`, fontSize: 13, color: C.textSub, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
            {aiText}
          </div>
        )}

        {!aiText && !loadingAI && (
          <div style={{ background: C.surface, borderRadius: 10, padding: 32, textAlign: "center" }}>
            <Brain size={32} style={{ color: C.purple, marginBottom: 12 }} />
            <div style={{ fontSize: 14, fontWeight: 700, color: C.text, marginBottom: 8 }}>Ready to Generate Briefing</div>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 20 }}>Claude will analyze your live metrics and generate an actionable morning briefing with TL-specific recommendations</div>
            <Btn onClick={fetchClaude} variant="primary" icon={Sparkles}>Generate AI Morning Briefing</Btn>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// TAB: TICKET COMMAND CENTER
// ═══════════════════════════════════════════════════════
function TicketTab({ trainers }) {
  const tickets = useMemo(() => {
    const cats = ["Login Issue","Sync Error","Menu Error","Printer Issue","KOT Error","Payment Issue"];
    const all = [];
    trainers.forEach(t => {
      for (let i = 0; i < t.zoho_sync.fatal_issues; i++) {
        all.push({
          id: `ZD-${t.id}-${i}`,
          trainer: t.name, tl: t.team_leader, state: t.state, city: t.city,
          category: cats[Math.floor(Math.random()*cats.length)],
          severity: i === 0 ? "high" : "medium",
          age: `${Math.floor(Math.random()*48+1)}h`,
          merchant: `Restaurant ${Math.floor(Math.random()*999+100)}`,
        });
      }
    });
    return all;
  }, [trainers]);

  const byTL = TEAM_LEADERS.map(tl => ({ ...tl, count: tickets.filter(t=>t.tl===tl.name).length })).sort((a,b)=>b.count-a.count);
  const byCat = ["Login Issue","Sync Error","Menu Error","Printer Issue","KOT Error","Payment Issue"].map(cat => ({
    name: cat, value: tickets.filter(t=>t.category===cat).length, fill: [C.danger,C.warning,C.info,C.brand,C.success,C.purple][["Login Issue","Sync Error","Menu Error","Printer Issue","KOT Error","Payment Issue"].indexOf(cat)]
  }));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
        <KPICard title="Total Open Tickets" value={tickets.length} sub="Zoho Desk unresolved" icon={ShieldAlert} color={C.danger} />
        <KPICard title="High Severity" value={tickets.filter(t=>t.severity==="high").length} sub="Needs immediate action" icon={AlertTriangle} color={C.danger} />
        <KPICard title="SLA Breached" value={Math.floor(tickets.length * 0.3)} sub=">48h unresolved" icon={Clock} color={C.warning} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 16 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {/* TL fatal counts */}
          <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 14 }}>Fatal Issues by TL</div>
            {byTL.map(tl => (
              <div key={tl.id} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, color: C.text }}>{tl.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 800, color: tl.count > 10 ? C.danger : tl.count > 5 ? C.warning : C.success }}>{tl.count}</span>
                </div>
                <div style={{ height: 5, background: C.cardBorder, borderRadius: 3 }}>
                  <div style={{ width: `${Math.min(100, (tl.count / (Math.max(...byTL.map(t=>t.count)) + 1)) * 100)}%`, height: "100%", background: tl.color, borderRadius: 3 }} />
                </div>
              </div>
            ))}
          </div>

          {/* Category donut */}
          <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 14 }}>By Category</div>
            <ResponsiveContainer width="100%" height={200}>
              <RPieChart>
                <Pie data={byCat} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {byCat.map((d,i) => <Cell key={i} fill={d.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, fontSize: 10 }} />
              </RPieChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {byCat.map(d => (
                <span key={d.name} style={{ fontSize: 9, color: C.textMuted, display: "flex", alignItems: "center", gap: 3 }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: d.fill, display: "inline-block" }} />{d.name}: {d.value}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Ticket list */}
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", marginBottom: 14 }}>Open Fatal Tickets</div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
              <thead>
                <tr style={{ background: C.surface }}>
                  {["Ticket ID","Trainer","TL","Category","Merchant","Severity","Age"].map(h=>(
                    <th key={h} style={{ padding: "8px 10px", textAlign: "left", fontSize: 10, fontWeight: 700, color: C.textMuted, borderBottom: `1px solid ${C.cardBorder}`, whiteSpace: "nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {tickets.slice(0,20).map((t,i)=>(
                  <tr key={t.id} style={{ borderBottom: `1px solid ${C.cardBorder}`, background: i%2===0?"transparent":C.surface+"40" }}>
                    <td style={{ padding:"8px 10px", color: C.brand, fontWeight: 700, fontFamily: "monospace", fontSize: 10 }}>{t.id}</td>
                    <td style={{ padding:"8px 10px", color: C.text }}>{t.trainer}</td>
                    <td style={{ padding:"8px 10px", color: C.textMuted }}>{t.tl.split(" ")[0]}</td>
                    <td style={{ padding:"8px 10px", color: C.textSub }}>{t.category}</td>
                    <td style={{ padding:"8px 10px", color: C.textMuted, fontSize: 10 }}>{t.merchant}</td>
                    <td style={{ padding:"8px 10px" }}>
                      <span style={{ padding:"2px 7px", borderRadius: 5, fontSize: 9, fontWeight: 700, background: t.severity==="high" ? C.dangerDim : C.warningDim, color: t.severity==="high" ? C.danger : C.warning, textTransform: "uppercase" }}>{t.severity}</span>
                    </td>
                    <td style={{ padding:"8px 10px", color: parseInt(t.age)>24 ? C.danger : C.textMuted, fontWeight: 600 }}>{t.age}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// TAB: TEAM & WORKFORCE
// ═══════════════════════════════════════════════════════
function TeamTab({ trainers }) {
  const [search, setSearch] = useState("");
  const [stateFilter, setStateFilter] = useState("all");
  const [badgeFilter, setBadgeFilter] = useState("all");

  const filtered = trainers.filter(t => {
    const ms = t.name.toLowerCase().includes(search.toLowerCase());
    const ss = stateFilter === "all" || t.state === stateFilter;
    const bs = badgeFilter === "all" || t.badge_level === badgeFilter;
    return ms && ss && bs;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "12px 16px" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 200 }}>
          <Search size={13} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: C.textMuted }} />
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search trainer..."
            style={{ width: "100%", background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "7px 10px 7px 30px", fontSize: 12, color: C.text, outline: "none", boxSizing: "border-box" }} />
        </div>
        <select value={stateFilter} onChange={e=>setStateFilter(e.target.value)} style={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "6px 10px", fontSize: 11, color: C.text, outline: "none" }}>
          <option value="all">All States</option>
          {STATES.map(s=><option key={s} value={s}>{s}</option>)}
        </select>
        <select value={badgeFilter} onChange={e=>setBadgeFilter(e.target.value)} style={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "6px 10px", fontSize: 11, color: C.text, outline: "none" }}>
          <option value="all">All Badges</option>
          <option value="gold">🥇 Gold</option>
          <option value="silver">🥈 Silver</option>
          <option value="bronze">🥉 Bronze</option>
        </select>
        <span style={{ padding: "6px 12px", background: C.brandDim, color: C.brand, borderRadius: 8, fontSize: 11, fontWeight: 700, border: `1px solid ${C.brandBorder}` }}>{filtered.length} trainers</span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px,1fr))", gap: 12 }}>
        {filtered.slice(0,30).map(t => {
          const sla = !t.is_checked_in ? (t.check_out_time ? "CHECKED_OUT" : "ABSENT") : t.today_sessions >= 4 ? "MET" : t.today_sessions >= 2 ? "ON_TRACK" : "BREACH";
          const slaLabel = { MET: "✅ SLA Met", ON_TRACK: "⏳ On Track", BREACH: "🔴 Breach", CHECKED_OUT: "— Checked Out", ABSENT: "⬜ Absent" };
          const slaCol = { MET: C.success, ON_TRACK: C.warning, BREACH: C.danger, CHECKED_OUT: C.textMuted, ABSENT: "#4B5563" };
          return (
            <div key={t.id} style={{ background: C.card, border: `1px solid ${sla === "BREACH" ? C.danger + "30" : C.cardBorder}`, borderRadius: 12, padding: 16, transition: "all 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.borderColor=C.brand+"40"}
              onMouseLeave={e=>e.currentTarget.style.borderColor=sla==="BREACH" ? C.danger+"30" : C.cardBorder}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{t.name}</div>
                  <div style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>{t.employee_code} • {t.city}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-end" }}>
                  <Badge level={t.badge_level} />
                  <StatusDot status={sla} />
                </div>
              </div>
              <div style={{ fontSize: 10, color: slaCol[sla], fontWeight: 700, marginBottom: 10 }}>{slaLabel[sla]}</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 12 }}>
                {[["Sessions",`${t.today_sessions}/4`],["⭐ Rating",t.star_rating.toFixed(1)],["TL",t.team_leader.split(" ")[0]],["Fatal",t.zoho_sync.fatal_issues]].map(([l,v])=>(
                  <div key={l} style={{ background: C.surface, borderRadius: 7, padding: "6px 9px" }}>
                    <div style={{ fontSize: 9, color: C.textMuted }}>{l}</div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                <a href={`https://wa.me/${t.phone}?text=${encodeURIComponent(`Hi ${t.name}, daily check-in from South Zone Operations.`)}`} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
                  <Btn size="xs" icon={MessageSquare} variant="success">WA</Btn>
                </a>
                <a href={`tel:${t.phone}`} style={{ textDecoration: "none" }}>
                  <Btn size="xs" icon={Phone}>Call</Btn>
                </a>
              </div>
            </div>
          );
        })}
      </div>
      {filtered.length > 30 && <div style={{ textAlign: "center", fontSize: 12, color: C.textMuted, padding: 10 }}>Showing 30 of {filtered.length} trainers — use filters to narrow results</div>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// MAIN APP SHELL
// ═══════════════════════════════════════════════════════
export default function App() {
  const [tab, setTab] = useState("home");
  const [time, setTime] = useState(new Date());
  const [trainers] = useState(TRAINERS_DATA);
  const summary = useMemo(() => computeSummary(trainers), [trainers]);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const TABS = [
    { id: "home", label: "Executive Overview", icon: LayoutDashboard },
    { id: "live", label: "Operations Command", icon: MapPin },
    { id: "productivity", label: "Training Analytics", icon: BarChart3 },
    { id: "predictive", label: "Predictive & AI", icon: Brain },
    { id: "tickets", label: "Ticket Center", icon: ShieldAlert },
    { id: "team", label: "Workforce", icon: Users },
  ];

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'Inter', system-ui, sans-serif", display: "flex", flexDirection: "column" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: ${C.surface}; }
        ::-webkit-scrollbar-thumb { background: ${C.cardBorder}; border-radius: 3px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.5; } }
      `}</style>

      {/* Header */}
      <header style={{ background: C.surface, borderBottom: `1px solid ${C.cardBorder}`, padding: "0 24px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: `linear-gradient(135deg, ${C.brand}, #FF8C42)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "#000" }}>P</div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 14, fontWeight: 800, color: C.text, letterSpacing: "-0.02em" }}>South Zone Operations Command</span>
              <span style={{ fontSize: 9, padding: "2px 7px", borderRadius: 10, background: C.successDim, color: C.success, fontWeight: 700, border: `1px solid ${C.success}30`, animation: "pulse 2s ease-in-out infinite" }}>● LIVE</span>
            </div>
            <div style={{ fontSize: 10, color: C.textMuted, marginTop: 1 }}>Petpooja Merchant Training Hub — God Mode Dashboard v3</div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          {/* Health score pill */}
          <div style={{ padding: "5px 14px", borderRadius: 20, background: summary.health_score >= 80 ? C.successDim : summary.health_score >= 60 ? C.warningDim : C.dangerDim, border: `1px solid ${summary.health_score >= 80 ? C.success : summary.health_score >= 60 ? C.warning : C.danger}40`, display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 800, color: summary.health_score >= 80 ? C.success : summary.health_score >= 60 ? C.warning : C.danger }}>Health: {summary.health_score}</span>
          </div>

          {/* Live clock */}
          <div style={{ fontFamily: "monospace", fontSize: 12, color: C.textMuted, letterSpacing: "0.05em" }}>
            IST {time.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: `${C.brand}25`, border: `1px solid ${C.brand}40`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: C.brand }}>AS</div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: C.text }}>Abdus Salam</div>
              <div style={{ fontSize: 9, color: C.textMuted }}>Zonal Manager • South Zone</div>
            </div>
          </div>
        </div>
      </header>

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* Sidebar Nav */}
        <nav style={{ width: 220, background: C.surface, borderRight: `1px solid ${C.cardBorder}`, padding: "20px 12px", display: "flex", flexDirection: "column", gap: 4, flexShrink: 0, overflowY: "auto" }}>
          <div style={{ fontSize: 9, fontWeight: 800, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", padding: "4px 8px 12px" }}>Navigation</div>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, border: "none", cursor: "pointer", textAlign: "left", transition: "all 0.15s",
              background: tab === t.id ? C.brandDim : "transparent",
              borderLeft: tab === t.id ? `2px solid ${C.brand}` : "2px solid transparent",
              color: tab === t.id ? C.brand : C.textMuted,
            }}>
              <t.icon size={15} />
              <span style={{ fontSize: 12, fontWeight: tab === t.id ? 700 : 500 }}>{t.label}</span>
            </button>
          ))}

          <div style={{ marginTop: "auto", borderTop: `1px solid ${C.cardBorder}`, paddingTop: 16, display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ fontSize: 9, fontWeight: 800, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", padding: "0 8px 6px" }}>Quick Metrics</div>
            {[
              { label: "Active Trainers", value: `${summary.total_checkins}/${summary.total_trainers}`, color: C.brand },
              { label: "Today Sessions", value: summary.total_sessions, color: C.success },
              { label: "SLA Breaches", value: summary.sla_breach_count, color: summary.sla_breach_count > 0 ? C.danger : C.success },
              { label: "Fatal Issues", value: summary.fatal_issues, color: summary.fatal_issues > 0 ? C.warning : C.success },
            ].map(m => (
              <div key={m.label} style={{ padding: "8px 10px", background: C.card, borderRadius: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 10, color: C.textMuted }}>{m.label}</span>
                <span style={{ fontSize: 12, fontWeight: 800, color: m.color }}>{m.value}</span>
              </div>
            ))}
          </div>
        </nav>

        {/* Main Content */}
        <main style={{ flex: 1, overflowY: "auto", padding: 24, background: C.bg }}>
          {tab === "home" && <HomeTab trainers={trainers} summary={summary} />}
          {tab === "live" && <LiveTab trainers={trainers} />}
          {tab === "productivity" && <ProductivityTab trainers={trainers} />}
          {tab === "predictive" && <PredictiveTab trainers={trainers} summary={summary} />}
          {tab === "tickets" && <TicketTab trainers={trainers} />}
          {tab === "team" && <TeamTab trainers={trainers} />}
        </main>
      </div>

      {/* Footer */}
      <footer style={{ background: C.surface, borderTop: `1px solid ${C.cardBorder}`, padding: "10px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 10, color: C.textMuted }}>© 2026 Petpooja South Zone Ops Suite • UOIP God Mode v3.0 • {trainers.length} trainers loaded</span>
        <span style={{ fontSize: 10, color: C.brand, fontFamily: "monospace" }}>Employee 0504 • Chennai HQ • TLs: Anil / Shyju / Mushtaq / Priya / Kiran</span>
      </footer>
    </div>
  );
}
